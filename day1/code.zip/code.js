//The variable likeCount is initialized to 0, and it keeps track of the number of likes
var likeCount = 0;

// This function is used to increase the value of likeCount var when  it is called
function increaseLikes() {
  // This operation increments the 'likeCount' by 1
  likeCount = likeCount + 1;
}
