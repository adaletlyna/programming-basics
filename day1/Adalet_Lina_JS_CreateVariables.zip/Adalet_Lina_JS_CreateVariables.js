var age = 12;
var height = 42;
var isoldEnough = age > 10; //age should be more than 10
var istallEnough = height >= 42; //height should be more than 42 inshes
console.log(isoldEnough);
console.log(istallEnough);
var isAbleToRide = isoldEnough && istallEnough; //to be able to ride both the age and the height sould satisfy the conditions
console.log(isAbleToRide); //output should be true
